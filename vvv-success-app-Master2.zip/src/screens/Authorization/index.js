import Authorization from './Authorization';

export default Authorization;
