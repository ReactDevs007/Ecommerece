import Separator from './Separator';

export default Separator;
