import AppImage from './AppImage';

export default AppImage;
