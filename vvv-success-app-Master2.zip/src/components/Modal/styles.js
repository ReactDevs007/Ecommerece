import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  modal: {
    backgroundColor: 'white',
    paddingTop: 25,
    top: 150,
    flex: 0,
    alignItems: 'center'
  }
});
