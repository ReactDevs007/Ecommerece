import FilterItem from './FilterItem';

export default FilterItem;
