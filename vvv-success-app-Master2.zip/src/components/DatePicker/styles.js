import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  label: {
    marginBottom: 8,
    marginTop: 0,
    textAlign: 'left',
    color: '#878787',
    fontFamily: 'Montserrat-Regular',
    fontSize: 11
  }
});
