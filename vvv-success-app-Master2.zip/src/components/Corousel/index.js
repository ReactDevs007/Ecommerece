import Corousel from './Corousel';

export default Corousel;
