import CatalogCategory from './CatalogCategory';

export default CatalogCategory;
