import PageLayout from './PageLayout';

export default PageLayout;
