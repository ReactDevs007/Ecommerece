import GenderSelect, { FeMaleIcon, MaleIcon } from './GenderSelect';

export { FeMaleIcon, MaleIcon };
export default GenderSelect;
