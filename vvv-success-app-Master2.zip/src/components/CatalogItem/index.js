import CatalogItem from './CatalogItem';

export default CatalogItem;
